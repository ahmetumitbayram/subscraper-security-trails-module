from core import ACUX
import sys



API_KEY = "1986ad8c0a5b3df4d7028d5f3c06e936c573ed6b2eb7b4a9284d44128326a7149"
SERVER = "52.146.14.237:3443"


if len(sys.argv) > 1:
    eee = open("domains.txt", 'r').read().splitlines()
    HOSTS = list((eee))
else:
    print("domains.txt required")
    exit()
    
acunetix = ACUX(host=SERVER,api=API_KEY,timeout=30)

for host in HOSTS:
    
    try:
        acunetix.add_and_start("https://" + host)
        print("sent {}".format(host))
    except:
        pass
        print("err")
