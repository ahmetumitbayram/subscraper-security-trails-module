# service account bez consentu
# https://developers.google.com/analytics/devguides/reporting/core/v4/quickstart/service-py
from apiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials

SCOPES = ['https://www.googleapis.com/auth/analytics.readonly']
KEY_FILE_LOCATION = './credentials.json'
VIEW_ID = 'xxxx'

credentials = ServiceAccountCredentials.from_json_keyfile_name(
  KEY_FILE_LOCATION, SCOPES)

analytics = build('analytics', 'v4', credentials=credentials)
