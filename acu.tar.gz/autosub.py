import sys
import os
import acunetix
import requests




if len(sys.argv) > 1:

    os.system("python3 subscraper.py " + sys.argv[1] + " -r domains.txt");
else:
    print("domain required")
    exit()

eee = open("domains.txt", 'r').read().splitlines()
HOSTS = list((eee))


for host in HOSTS:
    try:
        os.system("python2 acunetix.py " + host);
    except:
        pass
